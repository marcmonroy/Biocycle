// Twilio WhatsApp sender
// Reads sender from TWILIO_WHATSAPP_FROM env var (current: whatsapp:+16625688859)
//
// action: 'test_verification' — FIRST PRIORITY. Sends hardcoded code "999999",
//   returns full raw Twilio response. Use to test the Twilio path in isolation.
//
// action: 'send_verification'
//   → generates crypto-random 6-digit code server-side
//   → stores in whatsapp_verification_codes via Supabase REST API
//     (requires SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY env vars in Netlify —
//      NOT VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY)
//   → attempts plain text Body; on error 21656/63016 falls back to approved template
//
// Default (no action) — sends template message. Requires: to, teaserText.

const { randomInt } = require('crypto');

exports.handler = async (event) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }

  // ── Parse body ────────────────────────────────────────────────────────────
  let parsed = {};
  try {
    parsed = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const { to, language = 'EN', teaserText, action, userId } = parsed;

  console.log('[send-whatsapp] action:', action);
  console.log('[send-whatsapp] to:', to);

  // ── Credentials (needed by all paths) ────────────────────────────────────
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken  = process.env.TWILIO_AUTH_TOKEN;
  const from       = process.env.TWILIO_WHATSAPP_FROM || 'whatsapp:+16625688859';

  console.log('[send-whatsapp] TWILIO_WHATSAPP_FROM at runtime:', from);
  console.log('[send-whatsapp] TWILIO_ACCOUNT_SID present:', !!accountSid);
  console.log('[send-whatsapp] TWILIO_AUTH_TOKEN present:', !!authToken);

  // ── FIRST: test_verification ──────────────────────────────────────────────
  // Must be checked before any other validation so a missing `teaserText` does
  // not cause the function to fall through to the template route.
  if (action === 'test_verification') {
    console.log('[send-whatsapp] TEST MODE entered');

    if (!accountSid || !authToken) {
      return { statusCode: 500, headers: corsHeaders, body: JSON.stringify({ error: 'Missing Twilio credentials' }) };
    }
    if (!to) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'to is required for test_verification' }) };
    }

    const toNumber = to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;
    console.log('[send-whatsapp] TEST sending 999999 to:', toNumber, 'from:', from);

    const testPayload = new URLSearchParams({
      From: from,
      To:   toNumber,
      Body: 'BioCycle TEST: Your verification code is 999999. It expires in 10 minutes.',
    });

    try {
      const testRes = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            Authorization:  `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString('base64')}`,
          },
          body: testPayload.toString(),
        }
      );
      const testData = await testRes.json();
      console.log('[send-whatsapp] TEST Twilio status:', testRes.status);
      console.log('[send-whatsapp] TEST Twilio response:', JSON.stringify(testData));
      return {
        statusCode: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify({ twilio_status: testRes.status, twilio_response: testData }),
      };
    } catch (err) {
      console.error('[send-whatsapp] TEST fetch threw:', err.message);
      return { statusCode: 500, headers: corsHeaders, body: JSON.stringify({ error: err.message }) };
    }
  }

  // ── All other actions require Twilio credentials ──────────────────────────
  if (!accountSid || !authToken) {
    console.error('[send-whatsapp] Missing Twilio credentials');
    return { statusCode: 500, headers: corsHeaders, body: JSON.stringify({ error: 'Missing Twilio credentials' }) };
  }

  const toNumber = to && to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;

  // ── send_verification ─────────────────────────────────────────────────────
  if (action === 'send_verification') {
    if (!to || !userId) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'to and userId are required' }) };
    }

    const supabaseUrl        = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    console.log('[send-whatsapp] SUPABASE_URL present:', !!supabaseUrl);
    console.log('[send-whatsapp] SUPABASE_SERVICE_ROLE_KEY present:', !!supabaseServiceKey);

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('[send-whatsapp] Missing Supabase credentials — set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in Netlify env (not VITE_ prefixed)');
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Missing Supabase credentials: set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in Netlify env' }),
      };
    }

    const code      = String(randomInt(100000, 1000000));
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

    const dbHeaders = {
      'Content-Type':  'application/json',
      'apikey':        supabaseServiceKey,
      'Authorization': `Bearer ${supabaseServiceKey}`,
    };

    // Delete existing codes for this user
    try {
      const delRes = await fetch(
        `${supabaseUrl}/rest/v1/whatsapp_verification_codes?user_id=eq.${encodeURIComponent(userId)}`,
        { method: 'DELETE', headers: dbHeaders }
      );
      console.log('[send-whatsapp] Supabase DELETE status:', delRes.status);
    } catch (err) {
      console.warn('[send-whatsapp] Supabase DELETE error (non-fatal):', err.message);
    }

    // Insert new code
    const insertRes = await fetch(
      `${supabaseUrl}/rest/v1/whatsapp_verification_codes`,
      {
        method: 'POST',
        headers: { ...dbHeaders, Prefer: 'return=minimal' },
        body: JSON.stringify({
          user_id:    userId,
          code,
          expires_at: expiresAt,
          created_at: new Date().toISOString(),
        }),
      }
    );

    console.log('[send-whatsapp] Supabase INSERT status:', insertRes.status);
    if (!insertRes.ok) {
      const errText = await insertRes.text();
      console.error('[send-whatsapp] Supabase INSERT error:', errText);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ error: `DB insert failed (${insertRes.status}): ${errText}` }),
      };
    }

    // Send via approved template — ContentSid + ContentVariables
    const templateSid = language === 'es'
      ? 'HXa511293ce070bfd02ac0d799b2aa6526'
      : 'HX2a761c6b6589f010cd416d1bf4f386d8';

    const codeVar = `Your verification code is ${code}. Enter it in the BioCycle app to verify your account.`;

    const tmplPayload = new URLSearchParams({
      From:             from,
      To:               toNumber,
      ContentSid:       templateSid,
      ContentVariables: JSON.stringify({ '1': codeVar }),
    });

    console.log('[send-whatsapp] Sending template', templateSid, 'to:', toNumber, 'from:', from);

    const twilioRes = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization:  `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString('base64')}`,
        },
        body: tmplPayload.toString(),
      }
    );

    const twilioData = await twilioRes.json();
    console.log('[send-whatsapp] Twilio template status:', twilioRes.status);
    console.log('[send-whatsapp] Twilio template response:', JSON.stringify(twilioData));

    if (!twilioRes.ok) {
      return {
        statusCode: twilioRes.status,
        headers: corsHeaders,
        body: JSON.stringify({ error: twilioData.message || 'Twilio error', code: twilioData.code }),
      };
    }

    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ sid: twilioData.sid }),
    };
  }

  // ── Default: template message (scheduled / marketing) ────────────────────
  if (!to || !teaserText) {
    return {
      statusCode: 400,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'to and teaserText are required' }),
    };
  }

  const templateSid = language === 'ES'
    ? 'HXa511293ce070bfd02ac0d799b2aa6526'
    : 'HX2a761c6b6589f010cd416d1bf4f386d8';

  const safeTeaser = teaserText
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\x00-\x7F]/g, '')
    .replace(/\n/g, ' ')
    .substring(0, 160);

  const templatePayload = new URLSearchParams({
    From:             from,
    To:               toNumber,
    ContentSid:       templateSid,
    ContentVariables: JSON.stringify({ '1': safeTeaser }),
  });

  const response = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization:  `Basic ${Buffer.from(`${accountSid}:${authToken}`).toString('base64')}`,
      },
      body: templatePayload.toString(),
    }
  );

  const data = await response.json();
  console.log('[send-whatsapp] Template send status:', response.status, JSON.stringify(data));

  if (!response.ok) {
    return {
      statusCode: response.status,
      headers: corsHeaders,
      body: JSON.stringify({ error: data.message || 'Twilio error' }),
    };
  }

  return {
    statusCode: 200,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    body: JSON.stringify({ sid: data.sid }),
  };
};
